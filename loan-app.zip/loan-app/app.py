from flask import Flask, render_template, request, url_for, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length, ValidationError
import numpy as np
import pickle
import sklearn

# initializing app
app = Flask(__name__)
# loading the trained model
model = pickle.load(open('model.pkl', 'rb')) 
app.secret_key='abcdef'


# connecting to local mysql database
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root123@localhost:3306/userdb'
# tracking the changes
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

# create database tables in 'userdb' database
db = SQLAlchemy(app)
bcrypt= Bcrypt(app)

#login
login_manager= LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

@login_manager.user_loader
def load_user(user_id):
  return UserInfo.query.get(int(user_id))

class UserInfo(db.Model, UserMixin):
  id = db.Column(db.Integer, primary_key=True)
  username = db.Column(db.String(20), unique=True, nullable = False)
  password = db.Column(db.String(80), nullable = False)

with app.app_context():
  db.create_all()
  db.session.commit()

# Register Form
class RegisterForm(FlaskForm):
  username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

  password = PasswordField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Password"})

  submit = SubmitField("Register")
  
# Login Form
class LoginForm(FlaskForm):
  username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

  password = PasswordField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Password"})

  submit = SubmitField("Login")

# Home Page
@app.route('/')
def index():
  return render_template('home.html')

# Login Page
@app.route('/login', methods=['GET', 'POST'])
def login():
  form = LoginForm()
  if form.validate_on_submit():
    user = UserInfo.query.filter_by(username=form.username.data).first()
    if user:
      if bcrypt.check_password_hash(user.password, form.password.data):
        login_user(user)
        return redirect(url_for('predictpage'))
  return render_template('login.html', form=form)

# Loan Prediction Page
@app.route('/predict',  methods=['GET', 'POST'])
@login_required # access prediction page only after login
def predictpage():
  if request.method == 'POST':
    gender=int(request.form['gender'])
    
    married = int(request.form['married'])
    
    dependents = float(request.form['dependents'])
    
    education = int(request.form['education'])
   
    self_employed = float(request.form['self_employed'])

    applicantincome = int(request.form['applicantincome'])

    coapplicantincome = float(request.form['coapplicantincome'])

    loanamount = float(request.form['loanamount'])

    loan_amount_term = float(request.form['loan_amount_term'])

    credit_history = float(request.form['credit_history'])

    property_area = int(request.form['property_area'])

    prediction = model.predict([[gender,married, dependents, education, self_employed, applicantincome, coapplicantincome, loanamount, loan_amount_term, credit_history, property_area]])
    
    if prediction[0] == 'y':
      message = "Congratulations, you are eligible for a loan!"
    else:
      message = "Sorry, you are not eligible for a loan."

    return render_template('predict.html', message=message)
  return render_template('predict.html')

# Logout
@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
  logout_user()
  return redirect(url_for('login'))

# Register Page
@app.route('/register', methods=['GET', 'POST'])
def register():
  form = RegisterForm()

  if form.validate_on_submit():
    hashed_password = bcrypt.generate_password_hash(form.password.data)
    new_user = UserInfo(username=form.username.data, password=hashed_password)
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('login'))

  return render_template('register.html', form=form)
  
if __name__ == "__main__":
  app.run(debug=True)
